# lkl.js

Run Linux kernel in your browser *directly*.

This repository includes pre-compiled LKL.js files.
If you want to build LKL.js on your environment,
please read [lkl-js.txt](https://github.com/retrage/linux/blob/retrage/em-v2/Documentation/lkl-js.txt).
